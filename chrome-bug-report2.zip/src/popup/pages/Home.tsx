import { useEffect, useState } from 'react';
import { supabase } from '../../services/supabaseClient';
import { ReportList } from '../components/ReportList';
import { useAuth } from '../hooks/useAuth';
import { Report } from '../types/main';
export default function Home() {
    const user = useAuth();
    const [reports, setReports] = useState < Report[] > ([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (user?.id) {
            fetchReports(user.id);
        }
    }, [user]);

    const fetchReports = async (uid: string) => {
        setLoading(true);
        const { data } = await supabase
            .from('bug_reports')
            .select('*')
            .eq('user_id', uid)
            .order('timestamp', { ascending: false });
        setReports(data || []);
        setLoading(false);
    };

    const logout = async () => {
        await supabase.auth.signOut();
        chrome.storage.local.remove('user_id', () => {
            location.reload(); // or redirect to /login if using routing
        });
    };

    if (loading) return <p style={{ padding: 12 }}>Loading reports...</p>;

    return (
        <div style={{ padding: 12 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12 }}>

                <div>
                    <h2 style={{ margin: 0 }}>Your Reports</h2>
                    <p style={{ fontSize: 12, color: '#555', margin: '4px 0 0' }}>
                        Press <b>Alt + B</b> to flag broken buttons or links
                    </p>
                </div>
                <button onClick={logout} style={{
                    padding: '10px',
                    backgroundColor: 'red',
                    color: '#fff',
                    fontSize: 14,
                    fontWeight: 'bold',
                    border: 'none',
                    borderRadius: 4,
                    cursor: 'pointer',
                    height: '37px',
                }}>Logout</button>
            </div>
            <ReportList reports={reports} />
        </div>
    );
}
