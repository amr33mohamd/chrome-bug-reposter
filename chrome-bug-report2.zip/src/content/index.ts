/* ──────────────────────────────────────────────────────────────
   Bug Reporter – content script
   • Alt + B toggles highlight mode
   • Adds 🚩 button to every <button> / <a> once per page‑load
   • Ignores DOM mutations caused by its own buttons
   • No infinite loops, no page freeze
   ──────────────────────────────────────────────────────────── */

let highlight = false;                         // current mode
const FLAG_CLASS = 'bug-flagged';              // red outline class
const BTN_CLASS = 'flag-btn';                 // class for our 🚩
const FLAG_ATTR = 'data-flagged';             // attribute marks handled nodes
let observer: MutationObserver | null = null;  // global observer ref
let debounce: ReturnType<typeof setTimeout>;   // debounce handle

/* ── inject minimal CSS once ───────────────────────────────── */
(() => {
    const style = document.createElement('style');
    style.textContent = `
       .${FLAG_CLASS}{
         outline:2px solid red!important;
         position:relative;
         transition:outline 0.2s ease-in-out;
       }
       .${BTN_CLASS}{
         position:absolute;top:-6px;right:-6px;z-index:9999;
         background:#fff;border:1px solid #ccc;border-radius:50%;
         font:12px sans-serif;cursor:pointer;padding:2px 5px;
         box-shadow:0 1px 4px rgba(0,0,0,.2);
       }`;
    document.head.appendChild(style);
})();

/* ── keyboard toggle (Alt+B) ───────────────────────────────── */
window.addEventListener('keydown', e => {
    if (e.altKey && e.key.toLowerCase() === 'b') toggleHighlight();
});

/* ── master toggle ─────────────────────────────────────────── */
function toggleHighlight() {
    highlight = !highlight;
    if (highlight) {
        injectFlags();
        startObserver();
    } else {
        stopObserver();
        clearFlags();
    }
}

/* ── inject 🚩 buttons into new candidates ─────────────────── */
function injectFlags(nodes: NodeListOf<HTMLElement> = document.querySelectorAll('button, a')) {
    nodes.forEach(el => {
        if (el.hasAttribute(FLAG_ATTR)) return;             // already processed
        if (el.querySelector(`.${BTN_CLASS}`)) return;      // safety (shadow clones)

        el.setAttribute(FLAG_ATTR, '1');
        el.classList.add(FLAG_CLASS);
        el.style.position = 'relative';

        const btn = document.createElement('button');
        btn.className = BTN_CLASS;
        btn.textContent = '🚩';

        btn.onclick = ev => {
            ev.preventDefault();
            ev.stopPropagation();

            chrome.runtime.sendMessage({ type: 'PING_USER' }, res => {
                if (!res?.user_id) return alert('Please log in first.');

                const note = prompt('Describe the issue:');
                if (!note) return;

                chrome.runtime.sendMessage({
                    type: 'SAVE_REPORT',
                    payload: {
                        url: location.href,
                        text: el.textContent,
                        note,
                        timestamp: new Date().toISOString()
                    }
                });
            });
        };

        el.appendChild(btn);
    });
}

/* ── remove outlines & buttons (when mode off) ─────────────── */
function clearFlags() {
    document.querySelectorAll<HTMLElement>(`[${FLAG_ATTR}]`).forEach(el => {
        el.classList.remove(FLAG_CLASS);
        el.removeAttribute(FLAG_ATTR);
        el.querySelector(`.${BTN_CLASS}`)?.remove();
    });
}

/* ── watch DOM (SPA, dynamic changes) ──────────────────────── */
function startObserver() {
    stopObserver();

    observer = new MutationObserver(muts => {
        // if every changed node is our own flag button => ignore
        const interesting = muts.some(m =>
            [...m.addedNodes, ...m.removedNodes].some(
                n => n.nodeType === 1 && !(n as HTMLElement).classList.contains(BTN_CLASS)
            )
        );
        if (!interesting) return;

        clearTimeout(debounce);
        debounce = setTimeout(() => highlight && injectFlags(), 200);
    });

    observer.observe(document.body, { childList: true, subtree: true });
}

function stopObserver() { observer?.disconnect(); observer = null; }
