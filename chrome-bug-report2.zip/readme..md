# 🐞 Chrome Extension: Bug Reporter

A lightweight Chrome extension that lets users **flag broken buttons and links** on any web page, add a note, and submit the report to **Supabase**. Designed with React + Vite and modular content scripts that follow SOLID principles.

---

## 🔧 Features

- ✅ Highlights all `<button>` and `<a>` elements
- ✅ Hovering shows a 🚩 button to flag it
- ✅ Users can type a note (via modal or prompt)
- ✅ Reports sent to Supabase (includes URL, text, note, timestamp, user ID)
- ✅ Login/signup UI via Supabase Auth (email + password)
- ✅ Popup shows latest reports
- ✅ `Alt + B` toggles highlight mode
- ✅ Handles dynamic content on SPAs
- ✅ Clean UI with optional Tailwind or inline CSS

---

## 🗂️ Folder Structure

```
chrome-bug-reporter/
├── public/
│   └── icons/
├── src/
│   ├── background/
│   ├── content/
│   ├── popup/
│   ├── services/
│   └── types/
├── dist/
├── manifest.json
├── index.html
├── vite.config.ts
├── tsconfig.json
└── .env
```

---

## ⚙️ Environment Variables

Create a `.env` file in the root:

```
VITE_SUPABASE_URL=https://xyzcompany.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key
```

---

## 🚀 Getting Started

```bash
npm install
npm run dev     # start popup React dev
npm run build   # bundle popup, background, content scripts
```

---

## 🧪 Load in Chrome

1. Go to `chrome://extensions`
2. Enable **Developer mode**
3. Click **Load unpacked**
4. Select the `dist/` folder

---

## 🔐 Auth Handling

- On login, `user_id` is saved via `chrome.runtime.sendMessage`
- Background stores it in `chrome.storage.local`
- Content script always checks `PING_USER` dynamically

---

## 🧱 Report Schema (Supabase)

```sql
Table: bug_reports

Columns:
- id (UUID or BIGINT)
- url (text)
- text (text)
- note (text)
- timestamp (text)
- user_id (UUID or text)
```

---

## 📌 Keyboard Shortcuts

- `Alt + B` — Toggle highlight mode on/off

---

## 💡 Future Ideas

- Replace `prompt()` with modal
- Screenshot capture
- Severity tagging
- Admin dashboard

---

## 🛡️ License

MIT © 2025 – Built for technical assessment & learning.